-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: tbmd
-- ------------------------------------------------------
-- Server version	5.5.46-0ubuntu0.14.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actor`
--

DROP TABLE IF EXISTS `actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actor` (
  `movie_id` int(11) DEFAULT NULL,
  `people_id` int(11) DEFAULT NULL,
  KEY `movie_id` (`movie_id`),
  KEY `people_id` (`people_id`),
  CONSTRAINT `actor_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`),
  CONSTRAINT `actor_ibfk_2` FOREIGN KEY (`people_id`) REFERENCES `people` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actor`
--

LOCK TABLES `actor` WRITE;
/*!40000 ALTER TABLE `actor` DISABLE KEYS */;
INSERT INTO `actor` VALUES (1,2),(1,3),(1,4),(2,2),(2,3),(2,4),(3,2),(3,3),(3,4),(4,2),(4,3),(4,4),(5,5),(5,6),(5,7),(6,6),(6,7),(6,8),(7,6),(7,7),(7,8),(8,2),(8,9);
/*!40000 ALTER TABLE `actor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `director_id` int(11) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `submit_date` date NOT NULL,
  `image_link` varchar(120) DEFAULT NULL,
  `synopsis` blob,
  PRIMARY KEY (`id`),
  KEY `director_id` (`director_id`),
  CONSTRAINT `movie_ibfk_1` FOREIGN KEY (`director_id`) REFERENCES `people` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES (1,1,'Star Wars: Episode IV - A New Hope','1977-12-27','2015-11-23','18f9f753f97f555baaaf8e356a0c2bea.jpg','In a distant galaxy eons before the creation of the mythical planet known as Earth, vast civilizations have evolved, and ruling the galaxy is an interstellar Empire created from the ruins of an Old Republic that held sway for generations. It is a time of civil war, as solar systems have broken away from the Empire and are waging a war of rebellion. During a recent battle, technical schematics for a gigantic space station, code named the Death Star, have been unearthed by Rebel spies, and a young woman who is a dissident member of the Imperial Senate, under the cover of a diplomatic mission to the planet Alderaan, is trying to smuggle these plans to the Rebellion. But her spacecraft is attacked by a vast warship of the Empire and seized. The dissident Senator is captured, but the plans for the Death Star are nowhere to be found. While soldiers of the Empire search the nearby planet Tatooine, a series of incidents sweeps up a young desert farmer with dreams of being a fighter pilot in the Rebellion, as he winds up with the Death Star plans and also the assistance of an elderly hermit who once served as a warrior of an ancient order whose chosen weapons were powerful energy swords known as lightsabers. The pair recruit a cynical interstellar smuggler and his outsized alien copilot with an ancient freighter heavily modified for combat to help them reach Alderaan - but the planet is obliterated and now the foursome must rescue the young woman held prisoner by the Empire and lead an attack by the Rebellion against the Death Star before it can annihilate all hope of restoring freedom to the galaxy.'),(2,1,'Star Wars: Episode V - The Empire Strikes Back','1980-05-21','2015-11-23','0cc03cff5ec0b6cfe4d63f7b543baa8a.jpg','The story of Luke Skywalker, Han Solo, Princess Leia and the others did not end with the destruction of the Death Star - it continues in \"The Empire Strikes Back\". Imperial forces have since driven the Rebels to hide on the ice world Hoth. But even on such an icy, backwater world, they cannot escape the evil Darth Vader\'s eyes for long, and he devastates the Rebel base in an assault with the Imperial AT-AT walkers. Luke flees to Dagobah to begin Jedi training with Master Yoda, while Han Solo, Chewbacca, Princess Leia and C-3PO run the blockade of Imperial Star Destroyers in the Millennium Falcon. The Imperials pursue them across the galaxy and eventually catch up with them on Bespin. Now Darth Vader plans to use them as bait to lure Luke Skywalker to him, and turns Han Solo over to Boba Fett as a prize to be delivered to crime lord Jabba the Hutt. Luke learns a terrible family secret after losing a swordfight with the Dark Lord. Will he - and the others - escape the Empire\'s clutches?'),(3,1,'Star Wars: Episode VI - Return of the Jedi','1983-06-02','2015-11-23','b42cbee16270b0babe81e9c8d1429277.jpg','The Empire is more than halfway through construction of a new Death Star - almost twice as big, but more than twice as powerful. When completed, it will spell certain doom for Luke Skywalker and the Rebels. Han Solo is a prisoner of crime lord Jabba the Hutt, and Princess Leia soon finds herself in the gangster\'s hands. Luke Skywalker, aided by C-3PO and R2-D2, makes his way into Jabba\'s palace, hoping to secure his friends\' freedom. But the Hutt has no intention of doing so and tries to kill them all. After escaping from Jabba and the sands of Tatooine, they regroup with the Rebel fleet, which is massing for an attack against the new satellite battle station at Endor. Lando Calrissian is pressed into action to lead the Rebel fighter attack, while Han is put in charge of a group of soldiers to take out the shield generator protecting the Death Star. However, Luke surrenders to Vader\'s soldiers on Endor, and is taken in front of Vader\'s master - the Galactic Emperor - on the Death Star for final corruption to the Dark Side of the Force. The fleet of Imperial Star Destroyers ambushes the Rebels, cutting them off. Worse, the new Death Star begins turning its giant laser on the Rebel carriers. It appears that nothing will stop the Empire\'s triumph - unless things start to change quickly.'),(4,1,'Star Wars: The Force Awakens','2015-12-17','2015-11-23','b7198158ca75ead681599f631c2cd847.jpg','A continuation of the saga created by George Lucas and set thirty years after Star Wars: Episode VI - Return of the Jedi'),(5,1,'Star Wars: Episode I - The Phantom Menace','1999-07-16','2015-11-23','a8ab00f94417670457ab3520b37c85f5.jpg','It is a distant galaxy eons before the gestation of the planet Earth. Advancements in technology and science have allowed the evolution of millions of worlds that are otherwise in many respects still primitive. These worlds are somewhat loosely allied into an intergalactic Republic, whose capital world is the planet Coruscant, a planetary city. Upholding order for the Republic are the Jedi, an order of warriors endowed with near-super power derived from self-generated fields of energy known collectively as the Force. Within the Republic, dissident worlds have banded into an alliance known as the Trade Federation, and the Trade Federation is locked in a dispute with the peaceful world of Naboo. Two Jedi Knights, Qui-Gon Jinn and his youthful apprentice, Obi-Wan Kenobi, have been sent to Naboo to help mediate an end to the dispute, but Nute Gunray, an alien viceroy, orders them to be killed, and the two Jedi discover upon their escape that the Trade Federation will launch an invasion of Naboo. With the help of a well-meaning but hopelessly subliterate alien native of Naboo, Qui-Gon and Obi-Wan land on Naboo to rescue her ruler, Queen Amidala, a ruler whose rule is a mixture of monarchy and republican democracy. Escaping Naboo, they are attacked by a Federation baseship and are forced to land on the distant planet Tatooine, where in seeking parts to complete their journey to Coruscant they encounter a young boy, Anakin Skywalker, a slave who possesses a gift for the savagely dangerous sport of podracing - a gift that Qui-Gon deduces is part of a genetic makeup perfect for the Jedi Order. Anakin eventually joins with Qui-Gon and Obi-Wan, and in the process attracts the attention of one of Queen Amidala\'s handmaidens with a dramatic secret, and all reach Coruscant, but endless and pointless debate within the Republic\'s Senate leave them no choice but to strike out on their own to liberate Naboo, a task made all the more difficult because a traitor within Coruscant has at his command a dissident Jedi warrior who seeks the death of Qui-Gon and Obi-Wan.'),(6,1,'Star Wars: Episode II - Attack of the Clones','2002-05-16','2015-11-23','4c6d77d8088f4332c0ad831e27b72d23.jpg','As now-Senator Padmé Amidala returns to Coruscant to vote on an important Senatorial matter, an assassination attempt on her life prompts the Jedi Council to send Jedi Knight Obi-Wan Kenobi and his Padawan Anakin Skywalker to protect her and find out who the assassin is. As this is happening, a rogue Jedi named Count Dooku leads separatists on Geonosis to rebel against the Senate. Supreme Chancellor Palpatine moves for a vote for a Republic Army to protect the Republic, as there has not been a full-scale war since the formation of the Republic. As Obi-Wan\'s investigations lead him to Kamino, he finds a massive clone army being produced, with a bounty hunter - the last of the Mandalorians - named Jango Fett as the master clone. As he chases the elusive bounty hunter, Jango (and his cloned son Boba) leads Obi Wan to Geonosis, where he meets Count Dooku and finds a startling revelation about the former Jedi. As Anakin is left behind to protect Padmé, his feelings for her grow into something more than friendship. From Naboo to Tatooine, it grows into love for her. But when a tragedy strikes Anakin\'s life, he begins slipping away from the Light Side of the Force, and perhaps from the Force itself.'),(7,1,'Star Wars: Episode III - Revenge of the Sith','2005-05-19','2015-11-23','25ef4d5b67c7cebdd8c3f04d2badda0b.jpg','Three years after the onset of the Clone Wars; the noble Jedi Knights are spread out across the galaxy leading a massive clone army in the war against the Separatists. After Chancellor Palpatine is kidnapped, Jedi Master Obi-Wan Kenobi and his former Padawan, Anakin Skywalker, are dispatched to eliminate the evil General Grievous. Meanwhile, Anakin\'s friendship with the Chancellor arouses suspicion in the Jedi Order, and dangerous to the Jedi Knight himself. When the sinister Sith Lord, Darth Sidious, unveils a plot to take over the galaxy, the fate of Anakin, the Jedi order, and the entire galaxy is at stake. Upon his return, Anakin Skywalker\'s wife Padme Amidala is pregnant, but he is having visions of her dying in childbirth. Anakin Skywalker ultimately turns his back on the Jedi, thus completing his journey to the dark side and his transformation into Darth Vader. Obi-Wan Kenobi must face his former apprentice in a ferocious lightsaber duel on the fiery world of Mustafar.'),(8,1,'Indiana Jones and the Last Crusade','1989-06-30','2015-11-23','bf08e9c5697be05b118e0db6bf06f29c.jpg','After Adolf Hitler & the Nazis fail to obtain the Ark of the Covenant, Hitler orders the SS and Wehrmacht to go after the cup of Christ - the Holy Grail. Indiana Jones is pressed back into action after a mining magnate\'s lead researcher disappears mysteriously. The lead researcher is none other than Indy\'s dad, the feisty Professor Henry Jones. Meeting up with Dr. Elsa Schneider in Venice, Indiana & Marcus Brody discover that a 2nd marker that reveals the location of the grail is buried in the catacombs of a converted church. Escaping from rats, fire, gunmen, and a ship\'s propeller, Indy discovers that his dad is being held in a castle on the German border with Austria. When he & Dr. Schneider reach the castle Indy locates his father, but Elsa proves herself a turncoat, and even worse - so is the mining magnate, Walter Donovan! After Indy & Henry escape the castle, they head to Berlin to get the map & Henry\'s diary that provides critical information to those who seek the Grail. Marcus, however, is kidnapped by Nazis in Iskenderun, and Indy & Henry meet up with Sallah and start their own journey toward the \'Canyon of the Crescent Moon\'. They run into Donovan & the Nazis, and a huge fight ensues. Will Indy obtain the Grail and gain eternal life for himself & his father, giving the world a future of light, or will Adolf Hitler & the Nazis triumph and send the armies of darkness marching all over the world?');
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `image_link` varchar(120) DEFAULT NULL,
  `submit_date` date NOT NULL,
  `bio` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,'George','Lucas','1944-05-14','c14d66f1336128deb63c6947a31bfe74.jpg','2015-11-23','George Walton Lucas, Jr. was raised on a walnut ranch in Modesto, California. His father was a stationery store owner and he had three siblings. During his late teen years, he went to Downey High School and was very much interested in drag racing. He planned to become a professional race-car driver. However, a terrible car accident just after his high school graduation ended that dream permanently. The accident changed his views on life. He decided to attend Modesto Junior College before enrolling in the University of Southern California film school. As a film student, he made several short films including THX-1138: 4EB (Electronic Labyinth) which won first prize at the 1967-68 National Student Film Festival. In 1967, he was awarded a scholarship by Warner Brothers to observe the making of Finian\'s Rainbow (1968) which was being directed by Francis Ford Coppola. Lucas and Coppola became good friends and formed American Zoetrope in 1969. The company\'s first project was Lucas\' full-length version of THX 1138 (1971). In 1971, Coppola went into production for The Godfather (1972), and Lucas formed his own company, Lucasfilm Ltd. In 1973, he wrote and directed the semiautobiographical American Graffiti (1973) which won the Golden Globe and garnered five Academy Award nominations. This gave him the clout he needed for his next daring venture. From 1973 to 1974, he began writing the screenplay for Star Wars: Episode IV - A New Hope (1977). He was inspired to make this movie from Flash Gordon and the Planet of the Apes films. In 1975, he established I.L.M. (Industrial Light and Magic) to produce the visual effects needed for the movie. Another company called Sprocket Systems was established to edit and mix Star Wars and later becomes known as Skywalker Sound. His movie was turned down by several studios until 20th Century Fox gave him a chance. Lucas agreed to forego his directing salary in exchange for 40% of the film\'s box-office take and all merchandising rights. The movie went on to break all box office records and earned seven Academy Awards. It redefined the term \"blockbuster\". The rest is history. Lucas made the other Star Wars films and along with Steven Spielberg created the Indiana Jones series which made box office records of their own. From 1980 to 1985, Lucas was busy with the construction of Skywalker Ranch, built to accommodate the creative, technical, and administrative needs of Lucasfilm. Lucas also revolutionized movie theatres with the T.H.X. System which was created to maintain the highest quality standards in motion picture viewing. He went on to make several more movies that have introduced major innovations in film-making technology. He is chairman of the board of The George Lucas Educational Foundation. In 1992, George Lucas was honored with the Irving G. Thalberg Award by the Board of Governors of the Academy of Motion Picture Arts and Sciences for his life-time achievement.'),(2,'Harrison','Ford','1942-07-13','9517fd0bf8faa655990a4dffe358e13e.jpg','2015-11-23','Harrison Ford was born on July 13, 1942 in Chicago, Illinois, to Dorothy (Nidelman), a radio actress, and Christopher Ford (born John William Ford), an actor turned advertising executive. His father was of Irish and German ancestry, while his maternal grandparents were Jewish immigrants from Minsk, Belarus. Harrison was a lackluster student at Maine Township High School East in Park Ridge Illinois (no athletic star, never above a C average). After dropping out of Ripon College in Wisconsin, where he did some acting and later summer stock, he signed a Hollywood contract with Columbia and later Universal. His roles in movies and television (Ironside (1967), The Virginian (1962)) remained secondary and, discouraged, he turned to a career in professional carpentry. He came back big four years later, however, as Bob Falfa in American Graffiti (1973). Four years after that, he hit colossal with the role of Han Solo in Star Wars: Episode IV - A New Hope (1977). Another four years and Ford was Indiana Jones in Raiders of the Lost Ark (1981).\r\n\r\nFour years later and he received Academy Award and Golden Globe nominations for his role as John Book in Witness (1985). All he managed four years after that was his third starring success as Indiana Jones; in fact, many of his earlier successful roles led to sequels as did his more recent portrayal of Jack Ryan in Patriot Games (1992). Another Golden Globe nomination came his way for the part of Dr. Richard Kimble in The Fugitive (1993). He is clearly a well-established Hollywood superstar. He also maintains an 800-acre ranch in Jackson Hole, Wyoming.'),(3,'Mark','Hamill','1951-09-25','7edc6254373fcef79c1f248214fcd02b.jpg','2015-11-23','Mark Richard Hamill was born in Oakland, California, to Virginia Suzanne (Johnson) and William Thomas Hamill, a captain in the United States Navy. He grew up in California, Virginia, New York and Japan. He majored in drama at Los Angeles City College and made his acting debut on The Bill Cosby Show (1969) in 1970. He played a continuing role (Kent Murray) in the soap opera General Hospital (1963) and co-starred in the respected comedy series The Texas Wheelers (1974). Real fame came with his film debut (he was voice only in Wizards (1977)) with the hero role of Luke Skywalker in Star Wars: Episode IV - A New Hope (1977), Star Wars: Episode V - The Empire Strikes Back (1980) and Star Wars: Episode VI - Return of the Jedi (1983). He experienced a disfiguring car crash, but later played in Broadway, returning to film in 1989. During the 1990s, he became best known for providing the voice of the Joker on Batman: The Animated Series (1992).'),(4,'Carrie','Fisher','1956-10-21','5690cb3629d6cde717325a08ab5e3393.jpg','2015-11-23','Carrie Fisher was born on October 21, 1956 in Beverly Hills, Los Angeles, California, USA as Carrie Frances Fisher. She is an actress and writer, known for Star Wars: Episode IV - A New Hope (1977) (aka Star Wars: Episode IV - A New Hope (1977)), Star Wars: Episode V - The Empire Strikes Back (1980) and Star Wars: Episode VI - Return of the Jedi (1983). Fisher is also known for her book, \"Postcards From The Edge\", and Fisher wrote the screenplay for the movie from her novel. Carrie Fisher and talent agent Bryan Lourd have a daughter, Billie Lourd (Billie Catherine Lourd), born on July 17, 1992. Carrie Fisher and Bryan Lourd later separated. She was previously married to Paul Simon.'),(5,'Liam','Neeson','1952-06-07','ea91c5ecdfdb9a4638b246159bde16e0.jpg','2015-11-23','Liam Neeson was born on June 7, 1952 in Ballymena, Northern Ireland, UK, to Katherine (Brown), a cook, and Bernard Neeson, a school caretaker. Liam worked as a forklift operator for Guinness, truck driver, assistant architect and an amateur boxer. He had originally sought a career as a teacher by attending St. Mary\'s Teaching College, Newcastle. However, in 1976, Neeson joined the Belfast Lyric Players\' Theater and made his professional acting debut in the play \"The Risen People\". After two years, Neeson moved to Dublin\'s Abbey Theater where he performed the classics. It was here that he was spotted by director John Boorman and was cast in the film Excalibur (1981) as Sir Gawain, his first high-profile film role.\r\n\r\nThrough the 1980s Neeson appeared in a handful of films and British TV series - including The Bounty (1984), A Woman of Substance (1984), The Mission (1986), and Duet for One (1986) - but it was not until he moved to Hollywood to pursue larger roles that he began to get noticed. His turn as a mute homeless man in Suspect (1987) garnered good reviews, as did supporting roles in The Good Mother (1988) and High Spirits (1988) - though he also starred in the best-to-be-forgotten Satisfaction (1988), which also featured a then-unknown Julia Roberts - but leading man status eluded him until the cult favorite Darkman (1990), directed by Sam Raimi. From there, Neeson starred in Under Suspicion (1991) and Ethan Frome (1993), was hailed for his performance in Woody Allen\'s Husbands and Wives (1992), and ultimately was picked by Steven Spielberg to play Oskar Schindler in Schindler\'s List (1993). The starring role in the Oscar-winning Holocaust film brought Neeson Academy Award, BAFTA and Golden Globe nominations for Best Actor.'),(6,'Ewan ','McGregor','1971-03-31','4f893f5f9f1734aa3aeff10ea16c9fcc.jpg','2015-11-23','Ewan Gordon McGregor was born on March 31, 1971 in Crieff, Scotland, to Carol Diane (Lawson) and James Charles McGregor, both teachers. His uncle is actor Denis Lawson. At age 16, he left Crieff and Morrison Academy to join the Perth Repertory Theatre. His parents encouraged him to leave school and pursue his acting goals rather than be unhappy. McGregor studied drama for a year at Kirkcaldly in Fife, then enrolled at London\'s Guildhall School of Music and Drama for a three-year course. He studied alongside Daniel Craig and Alistair McGowan, among others, and left right before graduating after snagging the role of Private Mick Hopper in Dennis Potter\'s six-part Channel 4 series Lipstick on Your Collar (1993). His first notable role was that of Alex Law in Shallow Grave (1994), directed by Danny Boyle, written by John Hodge and produced by Andrew MacDonald. This was followed by The Pillow Book (1996) and Trainspotting (1996), the latter of which brought him to the public\'s attention.\r\n\r\nHe is now one of the most critically acclaimed actors of his generation, and portrays Obi-Wan Kenobi in the first three Star Wars episodes. McGregor is married to French production designer Eve Mavrakis, whom he met while working on the television series Kavanagh QC (1995). They married in France in the summer of 1995 and have two daughters, Clara Mathilde and Esther Rose. McGregor formed a production company, with friends Jonny Lee Miller, Sean Pertwee, Jude Law, Sadie Frost, Damon Bryant, Bradley Adams and Geoff Deehan, called \"Natural Nylon\", and hoped it would make innovative films that do not conform to Hollywood standards. McGregor and Bryant left the company in 2002. He was awarded Officer of the Order of the British Empire in the 2013 Queen\'s New Years Honours List for his services to drama and charity.'),(7,'Natalie','Portman','1981-06-09','786cfdfba44037b53f9a639e09a762b2.jpg','2015-11-23','Natalie Portman was born Natalie Hershlag on June 9, 1981, in Jerusalem, Israel, to a Jewish family. She is the only child of Avner Hershlag, an Israeli-born doctor, and Shelley Stevens, an American-born artist (from Cincinnati, Ohio), who also acts as Natalie\'s agent. She left Israel for Washington, D.C., when she was still very young. After a few more moves, her family finally settled in New York, where she still lives to this day. She graduated with honors, and her academic achievements allowed her to attend Harvard University. She was discovered by an agent in a pizza parlor at the age of 11. She was pushed towards a career in modeling but she decided that she would rather pursue a career in acting. She was featured in many live performances, but she made her powerful film debut in the movie Léon (1994) (aka \"Léon\"). Following this role Natalie won roles in such films as Heat (1995), Beautiful Girls (1996), and Mars Attacks! (1996).\r\n\r\nIt was not until 1999 that Natalie received worldwide fame as Queen Amidala in the highly anticipated US$431 million-grossing prequel Star Wars: Episode I - The Phantom Menace (1999). She then she starred in two critically acclaimed comedy dramas, Anywhere But Here (1999) and Where the Heart Is (2000), followed by Closer (2004), for which she received an Oscar nomination. She reprised her role as Padme Amidala in the last two episodes of the Star Wars prequel trilogy: Star Wars: Episode II - Attack of the Clones (2002) and Star Wars: Episode III - Revenge of the Sith (2005). She received an Academy Award and a Golden Globe Award for Best Actress in Black Swan (2010).'),(8,'Hayden','Christensen','1981-04-19','6b0164ab936f652de5e06e63e3137879.jpg','2015-11-23','Hayden Christensen was born April 19, 1981 in Vancouver, British Columbia, Canada. His parents, Alie and David Christensen, are in the communications business. He is of Danish (father) and Swedish and Italian (mother) descent. Hayden grew up in Markham, Ontario, with siblings Kaylen, Hejsa, and Tove. Hayden set out to become an actor when a chance encounter at the age of eight placed him in his first commercial, for Pringles. When he was thirteen, he had starring roles in several dramatic television series.\r\n\r\nHis biggest break was a major part in the Fox Family Network\'s Higher Ground (2000). On the series, Hayden showed off his acting talent as a teen who was sexually molested by his stepmother, and turns to drugs in despair. Later, he appeared in the television movie Trapped in a Purple Haze (2000), where he co-starred with his friend Jonathan Jackson. Hayden also had a role in the film The Virgin Suicides (1999).\r\n\r\nOn May 12, 2000, it was announced that Christensen would star as Anakin Skywalker in the prequels Star Wars: Episode II - Attack of the Clones (2002) and Star Wars: Episode III - Revenge of the Sith (2005). The star was chosen by director George Lucas because he felt that Hayden had raw talent and good chemistry with actress Natalie Portman. Lucas stunned the movie world by picking the then-unknown actor after he had turned down such big names as Leonardo DiCaprio and Jonathan Jackson, as well as 400 other candidates.\r\n\r\nHis role as the troubled, misunderstood teenager Sam Monroe in Irwin Winkler\'s Life as a House (2001) won him \'Breakthrough Performance of the Year\' from the National Board of Review. The film also placed him as a nominee for \'Best Supporting Actor\' at both the Golden Globe and Screen Actors Guild Awards. Hayden then starred in Shattered Glass (2003), quoted by some of the real Stephen Glass\' colleagues as giving an eerie and uncanny portrayal.\r\n\r\nSince his Star Wars days, Hayden has headlined several action films, including Jumper (2008) and Takers (2010).\r\n\r\nWhen not working, he enjoys spending quality time with his family (such as big brother Tove), hanging out with his friends, and exploring other hobbies such as the blues, jazz and piano.\r\n\r\nHayden has been in a relationship with actress Rachel Bilson for many years. The two have a child, born in 2014.'),(9,'Sean','Connery','1930-08-31','f852f9faafe01aa510ffbd2d875b8d37.jpg','2015-11-23','Thomas Sean Connery was born on August 25, 1930 in Fountainbridge, Edinburgh. His mother, Euphamia McBain (Maclean), was a cleaning lady, and his father, Joseph Connery, was a factory worker and truck driver. He also has a brother named Neil Connery, who works as a plasterer in Edinburgh. He is of Irish and Scottish descent. Before going into acting, Sean had many different jobs, such as a Milkman, lorry driver, a laborer, artist\'s model for the Edinburgh College of Art, coffin polisher and bodybuilder. He also joined the Royal Navy, but was later discharged because of medical problems. At the age of 23, he had a choice between becoming a professional footballer or an actor, and even though he showed much promise in the sport, he chose acting and said it was one of his more intelligent moves.\r\n\r\nNo Road Back (1957) was Sean\'s first major movie role, and it followed by several Tv-movies such as Anna Christie (1957), Macbeth (1961) and Anna Karenina (1961) and guest appearances on TV-series, and also films such as Hell Drivers (1957), Another Time, Another Place (1958), Darby O\'Gill and the Little People (1959), The Frightened City (1961). In 1962 he appeared in The Longest Day (1962) with a host of other stars,\r\n\r\nHis big breakthrough came in 1962 when he starred as secret agent James Bond in Dr. No (1962). He played James Bond in six more films: From Russia with Love (1963), Goldfinger (1964), Thunderball (1965), You Only Live Twice (1967), Diamonds Are Forever (1971), and Never Say Never Again (1983).\r\n\r\nAfter and during the success of the Bond-films he has maintained a successful career as an actor and has appeared in films, including Alfred Hitchcock\'s masterpiece Marnie (1964), The Hill (1965), Murder on the Orient Express (1974), The Man Who Would Be King (1975), The Wind and the Lion (1975), Time Bandits (1981), Highlander (1986), The Name of the Rose (1986), The Untouchables (1987) (which earned him an Oscar for best actor in a supporting role), Indiana Jones and the Last Crusade (1989), The Hunt for Red October (1990), Rising Sun (1993), The Rock (1996), Finding Forrester (2000), and The League of Extraordinary Gentlemen (2003).\r\n\r\nSean married actress Diane Cilento in 1962 and they had a son, Jason Connery, born on January 11, 1963, he followed in his father\'s footsteps and also became an actor. The marriage ended in divorce in 1973. In 1975 he married Micheline Roquebrune and they have stayed married, they have no children together. He is also a grandfather. His son, Jason and his ex-wife, actress Mia Sara had a son, Dashiell Quinn Connery, in 1997.');
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `submit_date` date NOT NULL,
  `rating` int(11) NOT NULL,
  `review_content` blob,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `movie_id` (`movie_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `join_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'bryan@tbmd.com','bryan@tbmd.com','*FEB6FA8C749C4963BBD06C433BDB424FA87B68B0','2015-11-23'),(2,'tim@tbmd.com','tim@tbmd.com','*E8CB293030DF5929BF3D3F0D285E235E46ABE9B1','2015-11-23');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-23 17:28:08
